import mongoose from "mongoose";

function calculatePacking(orderQtyBySize, cuttingQtyBySize) {
  const results = {};

  for (const size of Object.keys(orderQtyBySize)) {
    const orderMap = orderQtyBySize[size] || {};
    const availMap = { ...cuttingQtyBySize[size] };
    const colours = Object.keys(orderMap);
    const nonBlack = colours.filter(c => c.toLowerCase() !== 'black');
    const blackKey = colours.find(c => c.toLowerCase() === 'black');
    const totalOrder = Object.values(orderMap).reduce((a, b) => a + b, 0);

    // 1) NORMAL: 3x Black + 1x each non-black
    const maxNormalByBlack = Math.floor((availMap[blackKey] || 0) / 3);
    const maxNormalByColours = nonBlack.length
      ? Math.min(...nonBlack.map(c => Math.floor((availMap[c] || 0) / 1)))
      : 0;
    const normalBoxes = Math.min(maxNormalByBlack, maxNormalByColours);
    // consume
    if (blackKey) availMap[blackKey] -= normalBoxes * 3;
    nonBlack.forEach(c => (availMap[c] = (availMap[c] || 0) - normalBoxes));

    // fallback cap: 30% of totalOrder -> boxes of 8
    const maxFallback = Math.floor((totalOrder * 0.3) / 8);
    let option1Boxes = 0;
    let option2Boxes = 0;

    function bestDouble(min, requireAll = false) {
      const candidates = nonBlack.filter(c => (availMap[c] || 0) >= min);
      if (requireAll && candidates.length === 1) {
        const only = candidates[0];
        const ok = nonBlack.every(c => c === only || (availMap[c] || 0) >= 1);
        if (!ok) return null;
      }
      if (!candidates.length) return null;
      return candidates.reduce((a, b) => (availMap[b] > availMap[a] ? b : a));
    }

    // OPTION1: 3 Black, 2x one color, 1x three others
    while (option1Boxes + option2Boxes < maxFallback && (availMap[blackKey] || 0) >= 3) {
      const withOne = nonBlack.filter(c => (availMap[c] || 0) >= 1);
      if (withOne.length < 4) break;
      const dbl = bestDouble(2);
      if (!dbl) break;
      const others = nonBlack
        .filter(c => c !== dbl && (availMap[c] || 0) >= 1)
        .sort((a, b) => (availMap[b] || 0) - (availMap[a] || 0))
        .slice(0, 3);
      if (others.length < 3) break;
      availMap[blackKey] -= 3;
      availMap[dbl] -= 2;
      others.forEach(c => (availMap[c] -= 1));
      option1Boxes++;
    }

    // OPTION2: 2 Black, 2x one color, 1x each other
    while (option1Boxes + option2Boxes < maxFallback && (availMap[blackKey] || 0) >= 2) {
      if (!nonBlack.every(c => (availMap[c] || 0) >= 1)) break;
      const dbl = bestDouble(2, true);
      if (!dbl) break;
      availMap[blackKey] -= 2;
      availMap[dbl] -= 2;
      nonBlack.filter(c => c !== dbl).forEach(c => (availMap[c] -= 1));
      option2Boxes++;
    }

    results[size] = {
      normalBoxes,
      option1Boxes,
      option2Boxes,
      leftovers: { ...availMap }
    };
  }

  return results;
}

// Express controller
export const packingInfo = async (req, res) => {
  try {
    const { orderQty, cuttingQty } = req.body;
    if (!orderQty || !cuttingQty) {
      return res.status(400).json({ message: 'orderQty and cuttingQty required' });
    }

    // orderQty and cuttingQty should be objects: { size: { color: number, ... }, ... }
    const packingBySize = calculatePacking(orderQty, cuttingQty);

    return res.json({ packingBySize });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
};
